# 🚀 VENTURE PULSE - Blog de Negócios Digitais

![VENTURE PULSE](https://d2xsxph8kpxj0f.cloudfront.net/310519663719499525/Luv9Q6otkx8SzPqbppdLxn/venture-hero-banner-jLoXDrXfFm7xM4pxo8jnia.webp)

> Um blog premium especializado em negócios digitais, empreendedorismo e estratégias de crescimento. Conteúdo de alta qualidade para empreendedores e investidores.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Author](https://img.shields.io/badge/Author-Luiz%20Gustavo%20Santos-blue)](https://github.com/luizgustavo66101)

---

## 📋 Sobre o Projeto

**VENTURE PULSE** é um blog moderno com design warm organic premium dedicado a:

- 🎯 **Validação de Mercado** - Aprenda a validar sua ideia antes de investir
- 📈 **Growth Hacking** - Estratégias essenciais para crescimento exponencial
- ⚙️ **Operações Eficientes** - Otimize seus processos e aumente a produtividade
- 💰 **Funding para Startups** - Guia completo para conseguir investimento

---

## 🎨 Características

✨ **Design Premium Warm Organic**
- Paleta de cores acolhedora (laranja, terracota, verde sálvia)
- Layout moderno e acessível
- Interface responsiva (desktop, tablet, mobile)

🔍 **Otimizado para SEO**
- Meta tags otimizadas
- Schema.org JSON-LD
- Robots.txt e Sitemap.xml
- Open Graph para redes sociais

⚡ **Performance**
- Carregamento rápido (< 2 segundos)
- Imagens em CDN
- CSS inline minificado
- JavaScript otimizado

📱 **Responsividade**
- 100% mobile-friendly
- Funciona em todos os navegadores modernos
- Testes no Google Mobile-Friendly Test

---

## 🚀 Como Usar

### Localmente

```bash
# Clone o repositório
git clone https://github.com/luizgustavo66101/venture-pulse.git
cd venture-pulse

# Abra em um servidor local
python3 -m http.server 8000

# Ou com Node.js
npx http-server

# Acesse http://localhost:8000
```

### Deploy

1. Faça upload dos arquivos para seu servidor web
2. Configure o domínio
3. Pronto! Site ao vivo

### GitHub Pages

1. Vá para Settings do repositório
2. Vá em Pages
3. Selecione "Deploy from a branch"
4. Escolha a branch "main"
5. Seu site estará em: `https://luizgustavo66101.github.io/venture-pulse`

---

## 📁 Estrutura do Projeto

```
venture-pulse/
├── index.html              # Página principal
├── robots.txt              # Instruções para crawlers
├── sitemap.xml             # Mapa do site
├── README.md               # Este arquivo
├── .gitignore              # Arquivos ignorados pelo Git
├── LICENSE                 # Licença MIT
├── assets/                 # Recursos compilados
└── __manus__/              # Debug (opcional)
```

---

## 🎨 Customização

### Alterar Cores

Edite as variáveis CSS em `index.html`:

```css
:root {
    --primary: #ff8c42;      /* Laranja */
    --secondary: #b8860b;    /* Terracota */
    --accent: #6b8e23;       /* Verde Sálvia */
    --light-bg: #faf8f3;     /* Fundo claro */
    --text-dark: #2c2c2c;    /* Texto escuro */
}
```

### Adicionar Artigos

Copie um `.article-card` e customize o conteúdo.

### Atualizar Domínio

Substitua `seu-dominio.com` em:
- `index.html` (meta tags)
- `robots.txt`
- `sitemap.xml`

---

## 🔍 SEO

### Registrar no Google Search Console

1. Acesse: https://search.google.com/search-console
2. Adicione seu domínio
3. Envie o arquivo `sitemap.xml`
4. Verifique a propriedade

---

## 📊 Performance

- **Tamanho HTML**: ~35 KB
- **Imagens**: Em CDN
- **CSS**: Inline
- **JavaScript**: Mínimo
- **Tempo de Carregamento**: < 2 segundos

---

## 📞 Autor

**Luiz Gustavo Santos**
- 📧 Email: luizgustavo66200@mail.com
- 🔗 GitHub: [@luizgustavo66101](https://github.com/luizgustavo66101)
- 📸 Instagram: [@lzgustavo.07](https://instagram.com/lzgustavo.07)
- 📍 Localização: Curitiba, Brasil

---

## 📄 Licença

Este projeto está licenciado sob a Licença MIT.

---

**Última atualização**: 01 de Junho de 2026
